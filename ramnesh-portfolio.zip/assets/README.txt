Put your images in this folder (portrait.jpg, skot.png, etc.).
Then in index.html set the matching <img src=""> to e.g. src="assets/portrait.jpg".
